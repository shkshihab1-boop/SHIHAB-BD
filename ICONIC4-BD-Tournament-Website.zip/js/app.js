(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const cfg = window.FIREBASE_CONFIG || {};
  let appReady = false, auth = null, db = null, currentUser = null, tournaments = {};
  let language = "bn";

  const setMessage = (id, message, error = false) => {
    const el = $(id); if (!el) return;
    el.textContent = message; el.classList.toggle("error", !!error);
  };
  const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const money = (n) => "৳ " + Number(n || 0).toLocaleString("en-BD");
  const dateText = (value) => {
    if (!value) return "সময় জানানো হবে";
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? "সময় জানানো হবে" : d.toLocaleString(language === "bn" ? "bn-BD" : "en-GB", {dateStyle:"medium",timeStyle:"short"});
  };

  function initFirebase() {
    if (!window.firebase || !cfg.apiKey || cfg.apiKey.startsWith("PASTE_") || cfg.projectId?.startsWith("YOUR_")) {
      setMessage("registerMessage", "আগে js/firebase-config.js ফাইলে Firebase config বসান।", true);
      return false;
    }
    try {
      firebase.initializeApp(cfg);
      auth = firebase.auth(); db = firebase.database(); appReady = true;
      loadPublicData();
      auth.onAuthStateChanged(user => {
        currentUser = user;
        $("adminDashboard").hidden = !user;
        if (user) {
          setMessage("loginMessage", "লগইন হয়েছে।");
          loadAdminData();
        } else {
          $("registrationsBody").innerHTML = '<tr><td colspan="5">Admin login required.</td></tr>';
        }
      });
      return true;
    } catch (e) {
      console.error(e); setMessage("registerMessage", "Firebase চালু করা যায়নি। config যাচাই করুন।", true); return false;
    }
  }

  function loadPublicData() {
    db.ref("tournaments").on("value", snap => {
      tournaments = snap.val() || {};
      renderTournaments();
    }, err => console.error(err));
    db.ref("leaderboard").orderByChild("points").limitToLast(20).on("value", snap => {
      const rows = [];
      snap.forEach(child => rows.push({id:child.key,...child.val()}));
      rows.sort((a,b) => Number(b.points||0)-Number(a.points||0));
      $("leaderboardBody").innerHTML = rows.length ? rows.map((r,i) => `<tr><td>${i+1}</td><td>${escapeHtml(r.teamName)}</td><td>${Number(r.points||0)}</td><td>${Number(r.kills||0)}</td></tr>`).join("") : '<tr><td colspan="4" class="empty">এখনো কোনো ফলাফল প্রকাশ করা হয়নি।</td></tr>';
    }, err => console.error(err));
  }

  function renderTournaments() {
    const items = Object.entries(tournaments).map(([id,t]) => ({id,...t})).filter(t => t.active !== false);
    $("statTournaments").textContent = items.length;
    $("statPrize").textContent = money(items.reduce((sum,t)=>sum+Number(t.prize||0),0));
    const select = $("tournamentSelect");
    select.innerHTML = '<option value="">টুর্নামেন্ট নির্বাচন করুন</option>' + items.map(t => `<option value="${escapeHtml(t.id)}">${escapeHtml(t.name)} — ${escapeHtml(t.mode||"Squad")}</option>`).join("");
    $("tournamentGrid").innerHTML = items.length ? items.map(t => `
      <article class="tournament-card">
        <span class="mode">${escapeHtml(t.mode || "Squad")}</span>
        <h3>${escapeHtml(t.name)}</h3>
        <div class="meta"><span>◷ ${escapeHtml(dateText(t.startAt))}</span><span>♟ ${Number(t.slots||0)} slots</span></div>
        <p class="prize">${escapeHtml(money(t.prize))} <small style="font-size:10px;color:#a4adbd">PRIZE POOL</small></p>
        <a class="btn btn-red" href="#register" data-tournament="${escapeHtml(t.id)}">Register Team</a>
      </article>`).join("") : '<div class="empty">কোনো টুর্নামেন্ট নেই। অ্যাডমিন প্যানেল থেকে নতুন টুর্নামেন্ট তৈরি করুন।</div>';
    $("tournamentGrid").querySelectorAll("[data-tournament]").forEach(a => a.addEventListener("click", () => { select.value = a.dataset.tournament; }));
  }

  $("registerForm").addEventListener("submit", async e => {
    e.preventDefault();
    if (!appReady) { setMessage("registerMessage", "Firebase config বসিয়ে পেজ রিফ্রেশ করুন।", true); return; }
    const f = new FormData(e.currentTarget);
    const data = {
      teamName: String(f.get("teamName")).trim(),
      captainName: String(f.get("captainName")).trim(),
      captainUid: String(f.get("captainUid")).trim(),
      email: String(f.get("email")).trim().toLowerCase(),
      player2: String(f.get("player2")).trim(),
      player3: String(f.get("player3")).trim(),
      player4: String(f.get("player4")).trim(),
      tournamentId: String(f.get("tournamentId")).trim(),
      status: "pending",
      createdAt: firebase.database.ServerValue.TIMESTAMP
    };
    if (!tournaments[data.tournamentId]) { setMessage("registerMessage", "একটি বৈধ টুর্নামেন্ট নির্বাচন করুন।", true); return; }
    if ([data.captainUid,data.player2,data.player3,data.player4].some(uid => !/^[0-9]{5,20}$/.test(uid))) {
      setMessage("registerMessage", "প্রতিটি UID-তে ৫–২০টি সংখ্যা থাকতে হবে।", true); return;
    }
    try {
      await db.ref("registrations").push(data);
      e.currentTarget.reset();
      setMessage("registerMessage", "রেজিস্ট্রেশন জমা হয়েছে! অ্যাডমিন অনুমোদনের জন্য অপেক্ষা করুন।");
    } catch (err) {
      console.error(err); setMessage("registerMessage", "জমা দেওয়া যায়নি। Firebase Database Rules ও config যাচাই করুন।", true);
    }
  });

  $("loginForm").addEventListener("submit", async e => {
    e.preventDefault();
    if (!appReady) { setMessage("loginMessage", "আগে Firebase config বসান।", true); return; }
    const f = new FormData(e.currentTarget);
    try {
      await auth.signInWithEmailAndPassword(String(f.get("adminEmail")).trim(), String(f.get("adminPassword")));
      setMessage("loginMessage", "লগইন সফল।");
    } catch (err) {
      console.error(err); setMessage("loginMessage", "লগইন ব্যর্থ। ইমেইল/পাসওয়ার্ড ও Firebase Authentication যাচাই করুন।", true);
    }
  });
  $("logoutBtn").addEventListener("click", () => auth && auth.signOut());

  async function loadAdminData() {
    if (!currentUser) return;
    try {
      const snap = await db.ref("registrations").once("value");
      const list = [];
      snap.forEach(c => list.push({id:c.key,...c.val()}));
      list.sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
      $("statTeams").textContent = list.length;
      $("registrationsBody").innerHTML = list.length ? list.map(r => `
        <tr><td>${escapeHtml(r.teamName)}</td><td>${escapeHtml(r.captainName)}</td>
        <td>${escapeHtml(tournaments[r.tournamentId]?.name || "Unknown")}</td>
        <td><span class="status ${escapeHtml(r.status||"pending")}">${escapeHtml(r.status||"pending")}</span></td>
        <td><button class="action-btn" data-id="${escapeHtml(r.id)}" data-status="approved">Approve</button><button class="action-btn" data-id="${escapeHtml(r.id)}" data-status="rejected">Reject</button></td></tr>`).join("") : '<tr><td colspan="5">No registrations yet.</td></tr>';
      $("registrationsBody").querySelectorAll("[data-id]").forEach(btn => btn.addEventListener("click", async () => {
        try {
          await db.ref("registrations/"+btn.dataset.id+"/status").set(btn.dataset.status);
          setMessage("adminMessage", "Registration status updated.");
          loadAdminData();
        } catch (err) { console.error(err); setMessage("adminMessage", "Update failed. Check admin database rules.", true); }
      }));
    } catch (err) {
      console.error(err); setMessage("adminMessage", "ডেটা লোড হয়নি। আপনার UID admin allowlist-এ আছে কি না এবং Rules যাচাই করুন।", true);
    }
  }

  $("tournamentForm").addEventListener("submit", async e => {
    e.preventDefault(); if (!currentUser) return;
    const f = new FormData(e.currentTarget);
    const t = {
      name: String(f.get("name")).trim(), mode: String(f.get("mode")),
      startAt: new Date(String(f.get("startAt"))).toISOString(),
      prize: Number(f.get("prize")), slots: Number(f.get("slots")),
      active: true, createdAt: firebase.database.ServerValue.TIMESTAMP
    };
    try {
      await db.ref("tournaments").push(t);
      e.currentTarget.reset(); setMessage("adminMessage", "Tournament created.");
    } catch (err) { console.error(err); setMessage("adminMessage", "তৈরি করা যায়নি। Admin database rules যাচাই করুন।", true); }
  });

  $("resultForm").addEventListener("submit", async e => {
    e.preventDefault(); if (!currentUser) return;
    const f = new FormData(e.currentTarget);
    const row = {teamName:String(f.get("teamName")).trim(), points:Number(f.get("points")), kills:Number(f.get("kills")), updatedAt:firebase.database.ServerValue.TIMESTAMP};
    try {
      await db.ref("leaderboard").push(row);
      e.currentTarget.reset(); setMessage("adminMessage", "Result published.");
    } catch (err) { console.error(err); setMessage("adminMessage", "ফলাফল প্রকাশ করা যায়নি। Admin rules যাচাই করুন।", true); }
  });

  $("langBtn").addEventListener("click", () => {
    language = language === "bn" ? "en" : "bn";
    document.documentElement.lang = language;
    $("langBtn").textContent = language === "bn" ? "EN" : "বাংলা";
    document.querySelectorAll("[data-bn][data-en]").forEach(el => el.textContent = el.dataset[language]);
    renderTournaments();
  });
  $("menuBtn").addEventListener("click", () => $("nav").classList.toggle("open"));
  document.querySelectorAll("#nav a").forEach(a => a.addEventListener("click", () => $("nav").classList.remove("open")));

  initFirebase();
})();
