# ICONIC4 BD — সেটআপ গাইড (মোবাইল)

এই প্রজেক্টটি একটি responsive Free Fire community tournament website starter। এতে public tournament list, registration form, leaderboard এবং Firebase email/password admin login আছে।

## ১) ফাইল কোথায় রাখবে
- `index.html`
- `css/style.css`
- `js/firebase-config.js`
- `js/app.js`
- `firebase/database.rules.json`

সব ফাইলের ফোল্ডার স্ট্রাকচার একই রাখবে।

## ২) Firebase তৈরি
1. মোবাইল ব্রাউজারে https://console.firebase.google.com/ খোলো এবং Google account দিয়ে লগইন করো।
2. `Add project` দিয়ে নতুন project তৈরি করো, যেমন `iconic4-bd`.
3. Project settings → General → Your apps → Web app (`</>`) → app register করো।
4. Firebase config কপি করে `js/firebase-config.js`-এর placeholder-গুলো বদলাও।
5. Build → Authentication → Get started → Sign-in method → Email/Password enable করো।
6. Authentication → Users → Add user দিয়ে অ্যাডমিনের email/password তৈরি করো। শক্তিশালী, আলাদা পাসওয়ার্ড ব্যবহার করবে।
7. Build → Realtime Database → Create database।
8. Realtime Database → Rules-এ `firebase/database.rules.json`-এর নিয়ম বসিয়ে Publish করো।

## ৩) অ্যাডমিন UID অনুমোদন (অত্যন্ত গুরুত্বপূর্ণ)
1. Authentication → Users-এ অ্যাডমিনের UID কপি করো।
2. Realtime Database → Data-তে `admins` নামে node তৈরি করো।
3. তার ভেতরে child key হিসেবে ওই UID দাও এবং value `true` রাখো। উদাহরণ:
   `admins / YOUR_ADMIN_UID / true`
4. `admins` node-টি অন্য কেউ যেন লিখতে না পারে—উপরের Rules-এ `.write: false` আছে। Admin allowlist শুধু Firebase Console থেকে owner হিসেবে সেট করো।
5. Rules publish করার পরে অ্যাডমিন লগইন করে পরীক্ষা করো।

## ৪) মোবাইল দিয়ে অনলাইনে প্রকাশ
সহজ উপায় GitHub Pages:
1. https://github.com/ এ account খোলো।
2. New repository তৈরি করো, নাম `iconic4-bd`।
3. `Add file` → `Upload files` দিয়ে এই ZIP-এর ফাইলগুলো extract করে আপলোড করো; ZIP ফাইল নিজে আপলোড করলে সাইট চালু হবে না।
4. Repository → Settings → Pages → Deploy from a branch → `main` এবং `/(root)` নির্বাচন করে Save করো।
5. প্রকাশিত URL-এ খুলে পরীক্ষা করো। আপডেট হতে কয়েক মিনিট লাগতে পারে।

## ৫) নিরাপত্তা ও বাস্তব ব্যবহারের আগে
- Firebase config browser-এ দেখা যায়; সেটি secret নয়। নিরাপত্তা আসবে Database Rules থেকে।
- `admins/<UID> = true` শুধু নিজের বিশ্বস্ত অ্যাডমিন UID-এর জন্য দেবে।
- Public registration form-এ spam ঠেকাতে production-এ App Check, rate limiting বা server-side validation বিবেচনা করো।
- Rules-এ public registration শুধু নতুন রেকর্ড তৈরি করতে পারে; public read বন্ধ। Admin UID allowlist ছাড়া registrations পড়া/পরিবর্তন করা যাবে না।
- Rules-এর validation আরও শক্ত করা, duplicate UID/team registration ঠেকানো, slots limit enforce করা, payment handling এবং prize distribution-এর জন্য অতিরিক্ত backend logic লাগতে পারে।
- Prize money বা entry fee চালু করার আগে স্থানীয় আইন, গেমের টুর্নামেন্ট নীতি, বয়স ও পেমেন্ট-সংক্রান্ত নিয়ম যাচাই করো।
- GitHub Pages static hosting; এটি নিজে server-side code চালায় না।
- Free tier-এ quota/limits ও Firebase-এর শর্ত প্রযোজ্য।
- এই fan-run site Garena-এর official site নয়। Garena/Free Fire-এর নাম ও logo ব্যবহারের অনুমতি আছে ধরে নিও না।
